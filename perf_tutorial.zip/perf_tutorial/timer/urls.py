from django.urls import path
from timer.views import *

urlpatterns = [
       path("", index, name="blog_list"),

]